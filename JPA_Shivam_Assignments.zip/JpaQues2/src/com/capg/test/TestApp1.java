package com.capg.test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capg.entities.Book;

public class TestApp1 {
public static void main(String[] args) {
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JpaQues2");
		
		EntityManager manager = factory.createEntityManager();
		
		Book b1=new Book(103,"R.Milan",1005,"Computations",650);
		
		Book b2=new Book(104,"JL Nehru",1700,"History of india",900);
		
		
		manager.getTransaction().begin();
		
		manager.persist(b1);
		manager.persist(b2);
		manager.persist(b3);
		manager.persist(b4);
		
		manager.getTransaction().commit();
		
		System.out.println("data stored in database");
		factory.close();
	}

}
